# hunger_erase
A project done in Django using Python Framework for reducing the wastage of food .
